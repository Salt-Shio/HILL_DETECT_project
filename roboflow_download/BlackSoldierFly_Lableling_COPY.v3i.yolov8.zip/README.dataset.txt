# BlackSoldierFly_Lableling_COPY > 2025-05-14 3:13pm
https://universe.roboflow.com/salt-hiaow/blacksoldierfly_lableling_copy

Provided by a Roboflow user
License: CC BY 4.0

